package org.mule.modules.amazonec2.automation.connection;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mule.api.ConnectionException;
import org.mule.modules.amazonec2.automation.AbstractTestCase;
import org.mule.modules.amazonec2.config.ConnectorConfig;

import com.amazonaws.AmazonServiceException;

public class AmazonEC2ConnectionTest extends AbstractTestCase {

   ConnectorConfig awsConnConfig;
   final static String awsKeyId = "AKIAIO53YFTECOYGP22A";
   final static String awsKeySecret = "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";

   @Before
   public void setUp() {
      this.awsConnConfig = new ConnectorConfig();
   }

   // isConnected returns false after instantiation
   @Test
   public void beforeConnectIsConnectedReturnsFalse() {
      assertFalse(awsConnConfig.isConnected());
   }

   // isConnected returns true after connect method is successfully called
   @Test
   public void afterConnectIsConnectedReturnsTrue() throws ConnectionException {
      awsConnConfig.connect(awsKeyId, awsKeySecret);
      assertTrue(awsConnConfig.isConnected());
   }

   // isConnected returns false after connect is called successfully then
   // disconnect is called successfully
   @Test
   public void afterConnectThenDisconnectIsConnectedReturnsFalse() throws ConnectionException {
      awsConnConfig.connect(awsKeyId, awsKeySecret);
      assertTrue(awsConnConfig.isConnected());
      awsConnConfig.disconnect();
      assertFalse(awsConnConfig.isConnected());
   }

   // connect creates and points ec2Client to an instance of AmazonEC2Client
   @Test
   public void connectMethodSuccessfullyCreatesAWSClient() throws ConnectionException {
      awsConnConfig.connect(awsKeyId, awsKeySecret);
      assertNotNull(awsConnConfig.connectionId());
   }

}
