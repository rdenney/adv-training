package org.mule.modules.amazonec2.automation;

import org.junit.Before;
import org.mule.modules.amazonec2.AmazonEC2Connector;
import org.mule.tools.devkit.ctf.mockup.ConnectorDispatcher;
import org.mule.tools.devkit.ctf.mockup.ConnectorTestContext;

public abstract class AbstractTestCase {

   private AmazonEC2Connector connector;
   private ConnectorDispatcher<AmazonEC2Connector> dispatcher;

   protected AmazonEC2Connector getConnector() {
      return connector;
   }

   protected ConnectorDispatcher<AmazonEC2Connector> getDispatcher() {
      return dispatcher;
   }

   @SuppressWarnings("deprecation")
   @Before
   public void init() throws Exception {

      // Initialization for single-test run
      ConnectorTestContext.initialize(AmazonEC2Connector.class, false);

      // Context instance
      ConnectorTestContext<AmazonEC2Connector> context = ConnectorTestContext.getInstance(AmazonEC2Connector.class);

      // Connector dispatcher
      dispatcher = context.getConnectorDispatcher();

      connector = dispatcher.createMockup();

   }

}
