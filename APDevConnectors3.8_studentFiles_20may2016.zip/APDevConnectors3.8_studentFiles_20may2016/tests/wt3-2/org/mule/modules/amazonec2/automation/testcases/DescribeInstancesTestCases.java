package org.mule.modules.amazonec2.automation.testcases;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.mule.modules.amazonec2.automation.AbstractTestCase;

public class DescribeInstancesTestCases extends AbstractTestCase {

   @Test
   public void testFlow() throws Exception {
      assertEquals(getConnector().greet("Foo"), "Hello Foo. How are you?");
   }
}
